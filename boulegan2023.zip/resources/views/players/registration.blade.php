@extends('layouts.layout')

@section('title', "Inscriptions")

@section('content')

    <div class="container">
        @livewire('players.inscription')
    </div>

    
    
@endsection