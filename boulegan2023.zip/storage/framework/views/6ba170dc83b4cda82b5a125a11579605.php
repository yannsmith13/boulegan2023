<div>
    <?php if(!$closed): ?>
        <form wire:submit.prevent="register">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Nom :</label>
                <input type="text" wire:model="name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button class="btn" type="submit">Valider</button>
        </form>
    <?php else: ?>
        <h3>Inscriptions closes</h3>
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\boulegan2023\resources\views/livewire/players/register-form.blade.php ENDPATH**/ ?>