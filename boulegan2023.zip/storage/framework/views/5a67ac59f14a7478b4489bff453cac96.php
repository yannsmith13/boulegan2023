<div class="registration-container">
    
    <?php if(!$closed): ?>
        <?php if($settings->inscriptions): ?>
            <section>
                <h1 class="title-section">Inscriptions (<?php echo e($count); ?> participants)</h1>
                <form wire:submit.prevent="register">
                    <div class="form-group">
                        <label for="name">Nom :</label>
                        <input type="text" wire:model="name">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="btn" type="submit">Valider</button>
                </form>
            </section>
        <?php endif; ?>

    <?php endif; ?>

    
    <section class="index-players">
        <h2 class="title-section">
            Joueurs inscrits (<?php echo e($players->count()); ?>)
            <?php if($closed): ?>
                <span>(inscriptions closes)</span>
            <?php endif; ?>
        </h2>
        <ul class="players-list">
            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="item-players">
                    <span><?php echo e($player->name); ?></span>
                    <?php if($settings->inscriptions): ?>
                        <span class="remove-player" wire:click="remove(<?php echo e($player); ?>)">retirer</span>
                    <?php endif; ?>
                    
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <?php if($settings->inscriptions): ?>
            <?php if($count >= 16): ?>
                <div class="btn-section">
                    <a href="<?php echo e(route('teams.generateTeam', 'eliminatories')); ?>" class="btn">Démarrer phases
                        éliminatoires</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>



    </section>



</div>
<?php /**PATH C:\laragon\www\boulegan2023\resources\views/livewire/players/inscription.blade.php ENDPATH**/ ?>