<div>
    <?php if($finalIsReady): ?>
        <a href="#" class="btn">Finals</a>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\boulegan2023\resources\views/livewire/games/link-to-final.blade.php ENDPATH**/ ?>