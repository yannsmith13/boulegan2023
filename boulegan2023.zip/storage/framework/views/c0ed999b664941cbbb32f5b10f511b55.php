<div>
    <h1>Joueurs inscrits</h1>
    <ul>
        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($player->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <button>Tirer les équipes</button>
</div>
<?php /**PATH C:\laragon\www\boulegan2023\resources\views/livewire/players/index.blade.php ENDPATH**/ ?>