<?php $__env->startSection('title', "Inscriptions"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('players.inscription')->html();
} elseif ($_instance->childHasBeenRendered('PQE9OdD')) {
    $componentId = $_instance->getRenderedChildComponentId('PQE9OdD');
    $componentTag = $_instance->getRenderedChildComponentTagName('PQE9OdD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PQE9OdD');
} else {
    $response = \Livewire\Livewire::mount('players.inscription');
    $html = $response->html();
    $_instance->logRenderedChild('PQE9OdD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\boulegan2023\resources\views/players/registration.blade.php ENDPATH**/ ?>