<header>    
    <ul>
        <a href="<?php echo e(route('players.registration')); ?>">
            <li>Inscriptions</li>
        </a>
        <a href="<?php echo e(route('players.ranking')); ?>">
            <li>Classement poules</li>
        </a>
        
        <a href="<?php echo e(route('games.displayTour', 1)); ?>">
            <li>1er tour</li>
        </a>
        <a href="<?php echo e(route('games.displayTour', 2)); ?>">
            <li>2ème tour</li>
        </a>
        <a href="<?php echo e(route('games.displayTour', 3)); ?>">
            <li>3ème tour</li>
        </a>
        <a href="<?php echo e(route('games.displayTour', 4)); ?>">
            <li>Demi-finales</li>
        </a>
        <a href="<?php echo e(route('games.displayTour', 5)); ?>">
            <li>Finale</li>
        </a>
    </ul>
</header><?php /**PATH C:\laragon\www\boulegan2023\resources\views/components/header/header.blade.php ENDPATH**/ ?>