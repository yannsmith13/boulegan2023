<li class="game-section">
    <?php $__currentLoopData = $game->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="teams-section">
            <ul
                <?php if($team->win && $game->played): ?> class="team-item win"
            <?php elseif(!$team->win && $game->played): ?>
                class="team-item lose"
            <?php else: ?>
                class="team-item" <?php endif; ?>>
                <div>
                    <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="player-item">- <?php echo e($player->name); ?> -</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if($loop->first): ?>
                    <?php if(!$this->game->played): ?>
                        <input type="number" class="float-input-game float-input-game1" min="0" max="13"
                            wire:model="score1">
                    <?php else: ?>
                        <div class="float-input-game float-input-game1"><?php echo e($team->points); ?></div>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if(!$this->game->played): ?>
                        <input type="number" class="float-input-game float-input-game2" min="0" max="13"
                            wire:model="score2">
                    <?php else: ?>
                        <div class="float-input-game float-input-game2"><?php echo e($team->points); ?></div>
                    <?php endif; ?>
                <?php endif; ?>

            </ul>
        </div>
        <?php if($loop->first): ?>
            <?php if(!$game->played): ?>
                <div class="vs-team" wire:click="submitScore">VS</div>
            <?php else: ?>
                <div></div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</li>
<?php /**PATH C:\laragon\www\boulegan2023\resources\views/livewire/games/game.blade.php ENDPATH**/ ?>