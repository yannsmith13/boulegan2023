<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content'); ?>
    <ul class="container">
        <h2 class="title-section"><?php echo e($games[0]->name); ?></h2>
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('games.game', ["game" => $game])->html();
} elseif ($_instance->childHasBeenRendered($game->id)) {
    $componentId = $_instance->getRenderedChildComponentId($game->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($game->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($game->id);
} else {
    $response = \Livewire\Livewire::mount('games.game', ["game" => $game]);
    $html = $response->html();
    $_instance->logRenderedChild($game->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\boulegan2023\resources\views/games/display.blade.php ENDPATH**/ ?>