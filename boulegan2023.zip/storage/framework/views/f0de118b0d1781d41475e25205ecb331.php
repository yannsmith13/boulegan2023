<?php $__env->startSection('title', "Classement"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1 class="title-section">Classement phase éliminatoires</h1>

        <table class="ranking">
            <thead>
                <tr>
                    <th class="text-left">Joueur</th>
                    <th class="text-center">Victoires</th>
                    <th class="text-center">Diff.</th>
                    <th class="text-center">Points</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr <?php if($qualifiedPlayers->contains($player)): ?>
                        style="background: rgba(0, 128, 0, 0.2)"
                    <?php endif; ?>>
                        <td class="text-left"><span class="text-bold"><?php echo e($key + 1); ?></span> - <?php echo e(strtoupper($player->name)); ?></td>
                        <td class="text-center"><?php echo e($player->win); ?></td>
                        <td class="text-center"><?php echo e($player->diff > 0 ? "+".$player->diff : $player->diff); ?></td>
                        <td class="text-center"><?php echo e($player->points); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if($qualificationsAreClosed && !$semiFinalsAreOpen): ?>
            <div style="display: flex; margin-top: 0.75rem">
                <a href="<?php echo e(route('teams.generateSemiFinals')); ?>" class="btn">Direction les 1/2 finales</a>
            </div>
        <?php endif; ?>
        
    </div>

    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\boulegan2023\resources\views/players/ranking.blade.php ENDPATH**/ ?>