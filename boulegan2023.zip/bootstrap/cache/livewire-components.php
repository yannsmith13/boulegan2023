<?php return array (
  'games.game' => 'App\\Http\\Livewire\\Games\\Game',
  'games.link-to-final' => 'App\\Http\\Livewire\\Games\\LinkToFinal',
  'players.inscription' => 'App\\Http\\Livewire\\Players\\Inscription',
);